package pack2;
import pack1.*;
public class accessSpecifiers4 {


	public static void main(String[] args) {
			
			pubaccessspecifiers obj = new pubaccessspecifiers(); 
	        obj.display();  
			
		}
	}


